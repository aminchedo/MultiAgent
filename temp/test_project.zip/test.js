// سیستم تست خودکار پروژه
class ProjectTester {
    constructor() {
        this.tests = [];
        this.results = [];
        this.init();
    }

    init() {
        console.log('🧪 شروع تست‌های خودکار...');
        this.runAllTests();
    }

    // ========== Test Runner ==========
    async runAllTests() {
        // تست‌های اساسی DOM
        this.addTest('بارگذاری DOM', () => {
            return document.readyState === 'complete' && document.body !== null;
        });

        this.addTest('عملکرد JavaScript', () => {
            return typeof console !== 'undefined' && typeof document !== 'undefined';
        });

        this.addTest('پشتیبانی CSS', () => {
            const testElement = document.createElement('div');
            testElement.style.display = 'flex';
            return testElement.style.display === 'flex';
        });

        this.addTest('پشتیبانی Local Storage', () => {
            try {
                localStorage.setItem('test', 'test');
                localStorage.removeItem('test');
                return true;
            } catch (e) {
                return false;
            }
        });

        // تست‌های رسپانسیو
        this.addTest('پشتیبانی Media Queries', () => {
            return window.matchMedia && window.matchMedia('(max-width: 768px)').matches !== undefined;
        });

        // تست‌های کارایی
        this.addTest('Performance API', () => {
            return typeof performance !== 'undefined' && typeof performance.now === 'function';
        });

        // تست‌های مرورگر
        this.addTest('مرورگر مدرن', () => {
            return 'fetch' in window && 'Promise' in window && 'addEventListener' in window;
        });

        // تست‌های فونت
        this.addTest('بارگذاری فونت', () => {
            const element = document.createElement('div');
            element.style.fontFamily = 'Vazirmatn';
            document.body.appendChild(element);
            const fontFamily = window.getComputedStyle(element).fontFamily;
            document.body.removeChild(element);
            return fontFamily.includes('Vazirmatn') || fontFamily.includes('Arial');
        });

        // تست‌های امنیتی
        this.addTest('HTTPS Protocol', () => {
            return location.protocol === 'https:' || location.hostname === 'localhost';
        });

        // اجرای تست‌ها
        await this.executeTests();
        this.displayResults();
        this.showSummary();
    }

    addTest(name, testFunction, expectedResult = true) {
        this.tests.push({
            name,
            testFunction,
            expectedResult
        });
    }

    async executeTests() {
        for (const test of this.tests) {
            try {
                const startTime = performance.now();
                const result = await test.testFunction();
                const endTime = performance.now();
                const duration = Math.round(endTime - startTime);

                this.results.push({
                    name: test.name,
                    passed: result === test.expectedResult,
                    result,
                    expected: test.expectedResult,
                    duration,
                    error: null
                });

                console.log(`✅ ${test.name}: ${result ? 'موفق' : 'ناموفق'} (${duration}ms)`);
            } catch (error) {
                this.results.push({
                    name: test.name,
                    passed: false,
                    result: null,
                    expected: test.expectedResult,
                    duration: 0,
                    error: error.message
                });

                console.error(`❌ ${test.name}: خطا - ${error.message}`);
            }

            // تاخیر کوتاه برای نمایش پیشرفت
            await new Promise(resolve => setTimeout(resolve, 100));
        }
    }

    displayResults() {
        const container = document.getElementById('test-results');
        if (!container) return;

        container.innerHTML = '';

        this.results.forEach((result, index) => {
            const resultElement = document.createElement('div');
            resultElement.className = `test-result ${result.passed ? 'pass' : 'fail'}`;
            
            const icon = result.passed ? '✅' : '❌';
            const status = result.passed ? 'موفق' : 'ناموفق';
            const details = result.error ? 
                `خطا: ${result.error}` : 
                `زمان اجرا: ${result.duration}ms`;

            resultElement.innerHTML = `
                <div class="test-icon">${icon}</div>
                <div class="test-name">${result.name}</div>
                <div class="test-status">${status}</div>
                <div class="test-details">${details}</div>
            `;

            // انیمیشن ورود
            setTimeout(() => {
                container.appendChild(resultElement);
            }, index * 100);
        });
    }

    showSummary() {
        const passedTests = this.results.filter(r => r.passed).length;
        const totalTests = this.results.length;
        const successRate = Math.round((passedTests / totalTests) * 100);

        // به‌روزرسانی progress bar
        const progressFill = document.getElementById('progress-fill');
        if (progressFill) {
            setTimeout(() => {
                progressFill.style.width = `${successRate}%`;
                
                // تغییر رنگ بر اساس نتیجه
                if (successRate >= 90) {
                    progressFill.style.background = 'linear-gradient(90deg, #10b981, #059669)';
                } else if (successRate >= 70) {
                    progressFill.style.background = 'linear-gradient(90deg, #f59e0b, #d97706)';
                } else {
                    progressFill.style.background = 'linear-gradient(90deg, #ef4444, #dc2626)';
                }
            }, 500);
        }

        // نمایش خلاصه
        const summaryElement = document.getElementById('test-summary');
        if (summaryElement) {
            setTimeout(() => {
                let statusText = '';
                let statusIcon = '';
                
                if (successRate >= 90) {
                    statusText = 'عالی! پروژه آماده استقرار است';
                    statusIcon = '🎉';
                } else if (successRate >= 70) {
                    statusText = 'خوب! نیاز به بهبودهای جزئی';
                    statusIcon = '👍';
                } else {
                    statusText = 'نیاز به بررسی و اصلاح';
                    statusIcon = '⚠️';
                }

                summaryElement.innerHTML = `
                    <div style="font-size: 2rem; margin-bottom: 10px;">${statusIcon}</div>
                    <div style="font-size: 1.2rem; font-weight: 600; margin-bottom: 10px;">
                        ${passedTests} از ${totalTests} تست موفق (${successRate}%)
                    </div>
                    <div style="opacity: 0.9;">${statusText}</div>
                `;
            }, 1000);
        }

        // گزارش نهایی در کنسول
        console.log(`
🏆 خلاصه تست‌ها:
   ✅ موفق: ${passedTests}
   ❌ ناموفق: ${totalTests - passedTests}
   📊 درصد موفقیت: ${successRate}%
        `);
    }
}

// ========== Event Listeners ==========
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 سیستم تست آماده سازی شده');
    
    // شروع تست‌ها با تاخیر کوتاه
    setTimeout(() => {
        new ProjectTester();
    }, 500);
});

// تست‌های اضافی در صورت وجود عناصر خاص
window.addEventListener('load', () => {
    console.log('📄 صفحه کاملاً بارگذاری شد');
    
    // تست بارگذاری تصاویر
    const images = document.querySelectorAll('img');
    let loadedImages = 0;
    
    images.forEach(img => {
        if (img.complete) {
            loadedImages++;
        } else {
            img.addEventListener('load', () => {
                loadedImages++;
                if (loadedImages === images.length) {
                    console.log('✅ همه تصاویر بارگذاری شدند');
                }
            });
        }
    });
    
    if (images.length === 0) {
        console.log('ℹ️ هیچ تصویری یافت نشد');
    }
});