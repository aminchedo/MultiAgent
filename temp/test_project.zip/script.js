class AdvancedCalculator {
    constructor() {
        this.currentInput = '0';
        this.previousInput = '';
        this.operation = null;
        this.shouldResetDisplay = false;
        this.history = this.loadHistory();
        this.updateDisplay();
        this.updateHistoryDisplay();
        this.setupKeyboardListeners();
    }

    // ========== Input Methods ==========
    inputNumber(number) {
        if (this.shouldResetDisplay) {
            this.currentInput = '';
            this.shouldResetDisplay = false;
        }

        // جلوگیری از ورود چندین نقطه
        if (number === '.' && this.currentInput.includes('.')) {
            return;
        }
        
        // جایگزینی صفر ابتدایی
        if (this.currentInput === '0' && number !== '.') {
            this.currentInput = number;
        } else {
            this.currentInput += number;
        }
        
        this.updateDisplay();
    }

    operation(nextOperation) {
        const inputValue = parseFloat(this.currentInput);

        if (this.previousInput === '') {
            this.previousInput = inputValue;
        } else if (this.operation) {
            const result = this.performCalculation();
            
            if (result === null) return; // خطا در محاسبه
            
            this.currentInput = this.formatNumber(result);
            this.previousInput = result;
        }

        this.shouldResetDisplay = true;
        this.operation = nextOperation;
        this.updateDisplay();
    }

    calculate() {
        if (this.operation === null || this.shouldResetDisplay) {
            return;
        }

        const result = this.performCalculation();
        
        if (result === null) return; // خطا در محاسبه
        
        // ذخیره در تاریخچه
        const expression = `${this.formatNumber(this.previousInput)} ${this.getOperatorSymbol(this.operation)} ${this.currentInput}`;
        this.addToHistory(expression, result);
        
        this.currentInput = this.formatNumber(result);
        this.operation = null;
        this.previousInput = '';
        this.shouldResetDisplay = true;
        this.updateDisplay();
    }

    // ========== Calculation Methods ==========
    performCalculation() {
        const prev = parseFloat(this.previousInput);
        const current = parseFloat(this.currentInput);

        if (isNaN(prev) || isNaN(current)) {
            this.showError('خطا در ورودی');
            return null;
        }

        let result;
        switch (this.operation) {
            case '+':
                result = prev + current;
                break;
            case '-':
                result = prev - current;
                break;
            case '*':
                result = prev * current;
                break;
            case '/':
                if (current === 0) {
                    this.showError('تقسیم بر صفر ممکن نیست');
                    return null;
                }
                result = prev / current;
                break;
            default:
                return current;
        }

        // بررسی محدودیت‌های عددی
        if (!isFinite(result)) {
            this.showError('عدد خارج از محدوده');
            return null;
        }

        return result;
    }

    formatNumber(number) {
        if (typeof number !== 'number') return number;
        
        // رند کردن اعداد اعشاری طولانی
        if (number % 1 !== 0) {
            return parseFloat(number.toFixed(10)).toString();
        }
        
        return number.toString();
    }

    getOperatorSymbol(op) {
        const symbols = {
            '+': '+',
            '-': '−',
            '*': '×',
            '/': '÷'
        };
        return symbols[op] || op;
    }

    // ========== Utility Methods ==========
    clearAll() {
        this.currentInput = '0';
        this.previousInput = '';
        this.operation = null;
        this.shouldResetDisplay = false;
        this.clearError();
        this.updateDisplay();
    }

    clearEntry() {
        this.currentInput = '0';
        this.clearError();
        this.updateDisplay();
    }

    toggleSign() {
        if (this.currentInput !== '0') {
            this.currentInput = this.currentInput.startsWith('-') 
                ? this.currentInput.slice(1) 
                : '-' + this.currentInput;
            this.updateDisplay();
        }
    }

    // ========== Display Methods ==========
    updateDisplay() {
        const currentElement = document.getElementById('current');
        const historyElement = document.getElementById('history');
        
        if (currentElement) {
            currentElement.textContent = this.currentInput;
        }
        
        if (historyElement) {
            let historyText = '';
            if (this.previousInput !== '') {
                historyText = `${this.formatNumber(this.previousInput)} ${this.getOperatorSymbol(this.operation) || ''}`;
            }
            historyElement.textContent = historyText;
        }
    }

    showError(message) {
        const currentElement = document.getElementById('current');
        if (currentElement) {
            currentElement.textContent = message;
            currentElement.style.color = '#ff6b6b';
            
            setTimeout(() => {
                this.clearError();
            }, 2000);
        }
    }

    clearError() {
        const currentElement = document.getElementById('current');
        if (currentElement) {
            currentElement.style.color = '';
        }
    }

    // ========== History Methods ==========
    addToHistory(expression, result) {
        const historyItem = {
            expression,
            result: this.formatNumber(result),
            timestamp: new Date().toLocaleString('fa-IR', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit'
            }),
            id: Date.now()
        };
        
        this.history.unshift(historyItem);
        
        // محدود کردن تاریخچه به 50 آیتم
        if (this.history.length > 50) {
            this.history = this.history.slice(0, 50);
        }
        
        this.saveHistory();
        this.updateHistoryDisplay();
    }

    updateHistoryDisplay() {
        const historyList = document.getElementById('historyList');
        if (!historyList) return;

        if (this.history.length === 0) {
            historyList.innerHTML = '<div style="text-align: center; color: rgba(255,255,255,0.5); padding: 20px;">تاریخچه‌ای وجود ندارد</div>';
            return;
        }

        historyList.innerHTML = '';
        
        this.history.forEach(item => {
            const historyItem = document.createElement('div');
            historyItem.className = 'history-item';
            historyItem.innerHTML = `
                <div class="history-expression">${item.expression}</div>
                <div class="history-result">= ${item.result}</div>
                <div class="history-time">${item.timestamp}</div>
            `;
            
            // اضافه کردن قابلیت کلیک برای استفاده مجدد
            historyItem.addEventListener('click', () => {
                this.currentInput = item.result.toString();
                this.shouldResetDisplay = false;
                this.updateDisplay();
            });
            
            historyList.appendChild(historyItem);
        });
    }

    clearHistory() {
        this.history = [];
        this.saveHistory();
        this.updateHistoryDisplay();
    }

    saveHistory() {
        try {
            localStorage.setItem('calculatorHistory', JSON.stringify(this.history));
        } catch (e) {
            console.warn('نمی‌توان تاریخچه را ذخیره کرد:', e);
        }
    }

    loadHistory() {
        try {
            const saved = localStorage.getItem('calculatorHistory');
            return saved ? JSON.parse(saved) : [];
        } catch (e) {
            console.warn('نمی‌توان تاریخچه را بارگذاری کرد:', e);
            return [];
        }
    }

    // ========== Keyboard Support ==========
    setupKeyboardListeners() {
        document.addEventListener('keydown', (event) => {
            event.preventDefault(); // جلوگیری از رفتارهای پیش‌فرض
            
            const key = event.key;
            
            // اعداد و نقطه
            if (/[0-9.]/.test(key)) {
                this.inputNumber(key);
            }
            // عملگرها
            else if (['+', '-', '*', '/'].includes(key)) {
                this.operation(key);
            }
            // محاسبه
            else if (key === 'Enter' || key === '=') {
                this.calculate();
            }
            // پاک کردن
            else if (key === 'Escape') {
                this.clearAll();
            }
            else if (key === 'Backspace') {
                this.clearEntry();
            }
            // تغییر علامت
            else if (key === 'F9') {
                this.toggleSign();
            }
        });
    }
}

// ========== Global Functions ==========
let calculator;

// تابع‌های global برای دکمه‌ها
function inputNumber(number) {
    calculator.inputNumber(number);
}

function operation(op) {
    calculator.operation(op);
}

function calculate() {
    calculator.calculate();
}

function clearAll() {
    calculator.clearAll();
}

function clearEntry() {
    calculator.clearEntry();
}

function toggleSign() {
    calculator.toggleSign();
}

function clearHistory() {
    calculator.clearHistory();
}

// راه‌اندازی ماشین حساب
document.addEventListener('DOMContentLoaded', () => {
    calculator = new AdvancedCalculator();
    
    // نمایش پیام خوشامدگویی
    console.log('🧮 ماشین حساب پیشرفته آماده است!');
    console.log('📌 کلیدهای میانبر:');
    console.log('   • 0-9: ورود اعداد');
    console.log('   • +, -, *, /: عملگرها');
    console.log('   • Enter یا =: محاسبه');
    console.log('   • Escape: پاک کردن همه');
    console.log('   • Backspace: پاک کردن ورودی');
    console.log('   • F9: تغییر علامت');
});